const liText = [
"Autologous Bone Marrow Transplant - Marrow cells are collected from the patient’s own body and transfused back after high dose chemotherapy",
"Allogenic Bone Marrow Transplant (Matched Sibling Donor) – Replacement of diseased or defective marrow with marrow from a genetically (HLA) matched sibling donor.",
 "Allogenic Bone Marrow Transplant (Matched Unrelated Donor) – Replacement of diseased or defective marrow with marrow from a genetically (HLA) matched donor obtained from bone marrow registries in India and abroad.",
" Haplo-Identical Bone Marrow Transplant - Replacement of diseased or defective marrow with marrow from the parent.",
"Umbilical cord Bone Marrow Transplant - Replacement of diseased or defective marrow with marrow from a genetically (HLA) matched umbilical cord donor obtained from umbilical cord registries in India and abroad."
]


const cardText = [
    {
        text:"Failure to thrive – not gaining weight and height as per the age norms",
        img: "Images/group/group9.png"
    },
    {
        text:"Infections warranting multiple hospitalizations",
        img: "Images/group/group.png"
    },
    {
        text:"Requirement of intravenous antibiotics to clear infections",
        img:"Images/group/group1.png"
    },
    {
        text:"2 or more episodes of pneumonia",
        img:"Images/group/group2.png"
    },
    {
        text:"Family history of death of children at young age due to immune deficiency",
        img:"Images/group/group3.png"
    },
    {
        text:"Repeated episodes of diarrhea",
        img:"Images/group/group10.png"
    },
    {
        text:"2 or more episodes of sinus infections within a year",
        img:"Images/group/group6.png"
    },
    {
        text:"2 or more episodes of ear discharge",
        img:"Images/group/group7.png"
    },
    {
        text:"Repeated skin infections",
        img:"Images/group/group8.png"
    },
    {
        text:"Repeated abscess formation (liver abscess, brain abscess)",
        img:"Images/group/group5.png"
    },
];

accordionText =[
    {
        no:"One",
        text: "What are the conditions that requireBone Marrow Transplant?",
    },
    {
        no: "Two",
        text: " Which are the hematological diseases that may benefit from bone marrow transplants?",
    },
    {
        no: "Three",
        text: " Do bone marrow failure syndromes require BMT?",
    },
    {
        no: "Four",
        text: "What are Primary Immune Deficiency diseases ?",
    },
    {
        no: "Five",
        text: "Which are the immune deficiencies that warrant BMT?",
    },
    {
        no: "Six",
        text: " What makes transplants at Aster CMI unique?",
    },

]


function doctorContent() {
    const doctorCard = document.querySelectorAll(".doctor-card");
    console.log(doctorCard);

    doctorCard.forEach((card) => {
        // for(i=0; i< doctorCard.length; i++){
        // const doctor2 = document.querySelector("#doctor2");
       const div = document.createElement('div');
        const img = document.createElement('img');
        const doctorName = document.createElement('h3');
        const doctorOccupation = document.createElement('p');
        const doctorText = document.createElement('p');
        const button = document.createElement("button");
        div.classList.add("my-3", "card-elements");
        doctorName.classList.add("mt-4");
        doctorName.style.color = "#1D5AA6";
        doctorOccupation.style.color="#1D5AA6"
        doctorOccupation.style.opacity ="0.8";
        doctorText.classList.add('mt-5');
        button.classList.add("mb-4");
        button.classList.add("btn");
        button.style.background = "linear-gradient( #2EC4B8 ,10%, #6078EA)";
        button.style.color = "#fff";
        img.src = "Images/Bitmap Copy.png";
        img.alt = "Doctor Image";
        doctorName.textContent = "Dr. Vijay Agarwal";
        doctorOccupation.textContent = "MD, MRCP, PhD,CCT Lead & Sr. Consultant - Medical Oncology & Haematology";
        doctorText.textContent = "Dr. Vijay Agarwal is a Senior Consultant Medical Oncologist with over 12 years of experience in Oncology. Dr. Agarwal has been practising Medical Oncology since 2004.";
        button.textContent = "Know More";

      card.append(div, img, doctorName, doctorOccupation, doctorText, button);
        // console.log(card);
    });
}


function addListItem(liText){
    const boneMarrowText = document.querySelector(".bone-marrow-text");
    for(i=0; i < 5; i++){
        
        const li = document.createElement("li");  
        
        li.textContent = liText[i];
        li.classList.add("my-3");
        li.style.listStyle = "none";
        li.style.listStyleImage = "url(Images/hospital3.png)";
      
        boneMarrowText.appendChild(li);
        
        // console.log(liText.text + i)
        console.log(li);
        // console.log(typeof(liText.text1))
    }
}

const warningCard = document.querySelector(".warning-cards");

cardText.forEach((result)=>{
    const content = `<div class="card col-md-3">
    <div class="card-body ">
    <div class="card-img mb-4">
        <img src=${result.img} alt="">
    </div>
    <p class="card-text">${result.text}</p>
</div> 
</div>`;

warningCard.innerHTML += content;
});


for(i=0; i<3; i++){
    const content= `<div class="card col-lg-4">
    <div class="mx-2 px-2">
    <div class="d-flex col">
        <div class="test-img">
            <img src="Images/Bitmap.png" alt="Test">
        </div>
        <div class="test-heading m-auto">
            <h4>Jon Doe</h4>
            <p>Softwere Engineer</p>
        </div>
    </div>
    <div class="card-body ">
        <p class="card-text">It is a long established fact that a reader will be distracted by the readable
            content of a page when looking at its layout.</p>
    </div>        
    </div>
</div>`;

const testimonialContainer = document.querySelector(".testimonial-container");
testimonialContainer.innerHTML += content;
}


    accordionText.forEach((accordionItem)=>{
        const content = `<div class="accordion-item my-4">
        <h2 class="accordion-header" id="flush-heading${accordionItem.no}">
            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                data-bs-target="#flush-collapse${accordionItem.no}" aria-expanded="false" aria-controls="flush-collapse${accordionItem.no}">
                ${accordionItem.text}
            </button>
        </h2>
        <div id="flush-collapse${accordionItem.no}" class="accordion-collapse collapse" aria-labelledby="flush-heading${accordionItem.no}"
            data-bs-parent="#accordionFlushExample">
            <div class="accordion-body">
                BMT is the treatment of choice for blood disorders like Thalassemia, Sickle Cell anemia,
                bone marrow failure syndromes like Aplastic anemia, serious immune deficiencies and certain
                genetic metabolic disorders. It is also used to treat high risk cancers like some cases of
                Acute Lymphoblastic Leukemia, Acute Myeloid Leukemia, Multiple Myeloma and solid tumours
                like Neuroblastoma, Ewings Sarcoma and certain relapsed cancers like Lymphomas
            </div>
        </div>
    </div>`   
    const accContainer = document.querySelector(".acc-container");
    accContainer.innerHTML += content;
});





window.addEventListener('load', (event) => {
    // event.preventDeafault();
    doctorContent();
    addListItem(liText);

});